package com.example.finalproject;

import android.os.AsyncTask;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;

public class AsnycTaskClass extends AsyncTask<Object,String,String> {

    GoogleMap googleMap;
    String url;
    String allData;

    @Override
    protected void onPostExecute(String s) {
        List<HashMap<String, String>> placeList = null;
        getJSON json = new getJSON();
        placeList = json.parse(s);

        DisplayNearbyPlaces(placeList);
    }

    @Override
    protected String doInBackground(Object... objects) {

        googleMap = (GoogleMap)objects[0];
        url = (String)objects[1];

        URLConnect downloadUrl = new URLConnect();
        try
        {
            allData = downloadUrl.ReadTheURL(url);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        return allData;
    }
    private void DisplayNearbyPlaces(List<HashMap<String, String>> placeList) {
        for (int i=0; i<placeList.size(); i++) {
            MarkerOptions markerOptions = new MarkerOptions();
            HashMap<String, String> places = placeList.get(i);
            String vicinity = places.get("vicinity");
            String name = places.get("name");
            double lat = Double.parseDouble(places.get("lat"));
            double lng = Double.parseDouble(places.get("lng"));


            LatLng latLng = new LatLng(lat,lng);
            markerOptions.position(latLng);
            markerOptions.title(name+","+vicinity);
            markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
            googleMap.addMarker(markerOptions);
            googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            googleMap.animateCamera(CameraUpdateFactory.zoomTo(14));
        }
    }
}
