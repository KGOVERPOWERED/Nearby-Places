package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class markerIntent extends AppCompatActivity {
    TextView t1, t2;
    Button b;
    ArrayList<String>names = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marker_intent);

        t1 = findViewById(R.id.textView);
        t2 = findViewById(R.id.textView2);
        b = findViewById(R.id.button);


        Intent intent2 = getIntent();
        String title = intent2.getStringExtra("Name");
        double markerlat = intent2.getDoubleExtra("Latitude",0);
        double markerlng = intent2.getDoubleExtra("Longitude",0);
        double mainLat = intent2.getDoubleExtra("mainLocationLat",0);
        double mainLng = intent2.getDoubleExtra("mainLocationLng",0);

        Location mainLocation = new Location("main");
        mainLocation.setLatitude(mainLat);
        mainLocation.setLongitude(mainLng);

        Location markerLocation = new Location("marker");
        markerLocation.setLatitude(markerlat);
        markerLocation.setLongitude(markerlng);

        t1.setText(title);

        double distance = markerLocation.distanceTo(mainLocation);

        t2.setText("This location is "+distance+" meters away from your current location.");

        names.clear();
        File file = getApplicationContext().getFileStreamPath("Saved.txt");
        String line;

        if(file.exists()){
            try{
                BufferedReader br = new BufferedReader(new InputStreamReader(openFileInput("Saved.txt")));

                while((line=br.readLine())!=null){
                    String name = line;
                    names.add(name);
                }
                br.close();
            }catch(Exception e){

            }
        }



        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                names.add(title);

                try {
                    FileOutputStream fileOutputStream = openFileOutput("Saved.txt",MODE_PRIVATE);
                    OutputStreamWriter output = new OutputStreamWriter(fileOutputStream);

                    for(int i=0;i<names.size();i++)
                        output.write(names.get(i)+"\n");
                    output.flush();
                    output.close();
                    Toast.makeText(markerIntent.this,"Location Saved Successfully",Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(markerIntent.this,"Location not saved",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}