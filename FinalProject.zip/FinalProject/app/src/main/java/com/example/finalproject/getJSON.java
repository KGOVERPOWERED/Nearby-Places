package com.example.finalproject;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class getJSON {
    private HashMap<String, String> BasicJSONS(JSONObject object) {
        HashMap<String, String> mapData = new HashMap<>();
        String name = "";
        String vicinity = "";
        String jsonlat = "";
        String jsonlng = "";

        try {
            name = object.getString("name");
            vicinity = object.getString("vicinity");
            Log.d("vicinity",vicinity);
            jsonlat = object.getJSONObject("geometry").getJSONObject("location").getString("lat");
            jsonlng = object.getJSONObject("geometry").getJSONObject("location").getString("lng");


            mapData.put("name", name);
            mapData.put("vicinity", vicinity);
            mapData.put("lat", jsonlat);
            mapData.put("lng", jsonlng);
        }
        catch (JSONException e) {
            e.printStackTrace();
        }

        return mapData;
    }



    private List<HashMap<String, String>> getAllNearbyPlaces(JSONArray jsonArray) {
        int counter = jsonArray.length();
        List<HashMap<String, String>> hashMapList = new ArrayList<>();

        HashMap<String, String> HashMapJSONs = null;

        for (int i=0; i<counter; i++){
            try {
                HashMapJSONs = BasicJSONS((JSONObject) jsonArray.get(i));
                hashMapList.add(HashMapJSONs);
            }
            catch (JSONException e){
                e.printStackTrace();
            }
        }

        return hashMapList;
    }



    public List<HashMap<String, String>> parse(String JSONdata){
        JSONArray results=null;
        JSONObject mainData;

        try {
            mainData = new JSONObject(JSONdata);
            results = mainData.getJSONArray("results");
        }
        catch (JSONException e) {
            e.printStackTrace();
        }

        return getAllNearbyPlaces(results);
    }
}
